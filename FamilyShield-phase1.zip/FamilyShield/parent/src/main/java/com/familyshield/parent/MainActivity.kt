package com.familyshield.parent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.ui.res.stringResource
import com.familyshield.core.ui.FamilyShieldTheme
import com.familyshield.core.ui.HomePlaceholder
import com.familyshield.core.R as CoreR

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FamilyShieldTheme {
                HomePlaceholder(
                    title = stringResource(R.string.app_name),
                    subtitle = stringResource(CoreR.string.home_parent_subtitle),
                    privacyNote = stringResource(CoreR.string.privacy_note),
                )
            }
        }
    }
}
