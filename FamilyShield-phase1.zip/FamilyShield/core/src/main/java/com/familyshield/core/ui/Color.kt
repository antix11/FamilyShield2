package com.familyshield.core.ui

import androidx.compose.ui.graphics.Color

// Calm, family-friendly palette (teal + soft sand)
val Teal40 = Color(0xFF1F7A7A)
val Teal80 = Color(0xFF8FD3D0)
val Teal90 = Color(0xFFC9EFEC)
val Teal10 = Color(0xFF00201F)
val Sand40 = Color(0xFF6B5E4B)
val Sand80 = Color(0xFFD9C9B0)
val Sand90 = Color(0xFFF5E8D3)
val Sand10 = Color(0xFF251A08)
val SurfaceLight = Color(0xFFF8FAF9)
val SurfaceDark = Color(0xFF101414)
val ErrorLight = Color(0xFFB3261E)
val ErrorDark = Color(0xFFF2B8B5)
