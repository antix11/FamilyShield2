package com.familyshield.core.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = Teal40,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    primaryContainer = Teal90,
    onPrimaryContainer = Teal10,
    secondary = Sand40,
    onSecondary = androidx.compose.ui.graphics.Color.White,
    secondaryContainer = Sand90,
    onSecondaryContainer = Sand10,
    background = SurfaceLight,
    surface = SurfaceLight,
    error = ErrorLight,
)

private val DarkColors = darkColorScheme(
    primary = Teal80,
    onPrimary = Teal10,
    primaryContainer = Teal40,
    onPrimaryContainer = Teal90,
    secondary = Sand80,
    onSecondary = Sand10,
    secondaryContainer = Sand40,
    onSecondaryContainer = Sand90,
    background = SurfaceDark,
    surface = SurfaceDark,
    error = ErrorDark,
)

/** Shared theme. Follows system Light/Dark; RTL follows the app locale automatically. */
@Composable
fun FamilyShieldTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content,
    )
}
